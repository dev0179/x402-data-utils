"use client"

import { Switch } from "@/components/ui/switch"

interface HeaderProps {
  isPaid: boolean
  setIsPaid: (isPaid: boolean) => void
}

export function Header({ isPaid, setIsPaid }: HeaderProps) {
  return (
    <div className="border-b border-border/50 backdrop-blur-sm sticky top-0 z-50 bg-background/80">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center gap-3">
            <div className="flex items-center justify-center w-10 h-10 rounded-xl bg-gradient-to-br from-primary to-accent">
              <span className="text-xl font-bold text-primary-foreground">x</span>
            </div>
            <div>
              <h1 className="text-xl font-bold tracking-tight text-balance">x402 Payment Protocol</h1>
              <p className="text-sm text-muted-foreground">HTTP 402 → 200 Demo Interface</p>
            </div>
          </div>

          <div className="flex items-center gap-2 px-3 py-1.5 rounded-lg border border-border bg-muted/50">
            <span className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">Mock Mode</span>
          </div>
        </div>

        <div className="flex flex-col sm:flex-row sm:items-center gap-4">
          <div className="flex items-center gap-3 px-4 py-3 rounded-xl border border-border bg-card/50 backdrop-blur-sm hover:bg-card transition-colors">
            <Switch checked={isPaid} onCheckedChange={setIsPaid} className="data-[state=checked]:bg-primary" />
            <div className="flex-1">
              <label className="text-sm font-semibold cursor-pointer">Mock Payment Header</label>
              <p className="text-xs text-muted-foreground">Include X-X402-Mock-Paid header</p>
            </div>
          </div>

          <div className="text-sm text-muted-foreground">
            Toggle to simulate payment and bypass 402 responses. All operations are local and free.
          </div>
        </div>
      </div>
    </div>
  )
}
